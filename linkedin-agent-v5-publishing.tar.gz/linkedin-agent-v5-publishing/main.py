"""
LinkedIn Agent - Smartphone Edition
Kein Google Drive nötig - läuft komplett standalone
"""

import os
from flask import Flask, render_template, request, jsonify, redirect
from memory.simple_memory import SimpleMemory
from agents.research_agent import ResearchAgent
from agents.content_agent import ContentAgent
from agents.analytics_agent import AnalyticsAgent
from agents.publishing_agent import PublishingAgent

app = Flask(__name__)

# Initialize Memory (Simple File-based)
memory = SimpleMemory()

# Initialize Agents
research_agent = ResearchAgent(memory)
content_agent = ContentAgent(memory)
analytics_agent = AnalyticsAgent(memory)
publishing_agent = PublishingAgent(memory, analytics_agent)

# Connect Agents
research_agent.connect_to('content_agent', content_agent)
content_agent.connect_to('research_agent', research_agent)


@app.route('/')
def dashboard():
    """Main Dashboard"""
    profile = memory.load_profile()
    if not profile:
        return redirect('/onboarding')
    
    # Check for photos
    photos = memory.get_photos()
    if len(photos) < 5:
        return redirect('/settings/photos?required=true')
    
    proposals = memory.get_pending_proposals()
    stats = memory.get_stats()
    
    return render_template('dashboard_v2.html',
                         proposals=proposals,
                         stats=stats,
                         profile=profile)


@app.route('/fetch_news')
def fetch_news():
    """Fetch trending news for post ideas"""
    try:
        news = research_agent.get_trending_topics()
        return jsonify({'success': True, 'news': news})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/generate_post', methods=['POST'])
def generate_post():
    """Generate a single post iteratively"""
    try:
        data = request.json
        idea = data.get('idea')
        
        # Generate post
        post = content_agent.generate_single_post(idea)
        
        return jsonify({
            'success': True,
            'post': post
        })
        
    except Exception as e:
        import traceback
        print(f"❌ Error: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/approve_post/<post_id>', methods=['POST'])
def approve_post(post_id):
    """Approve a post"""
    try:
        memory.update_post_status(post_id, 'approved')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/regenerate_post', methods=['POST'])
def regenerate_post():
    """Regenerate post with feedback"""
    try:
        data = request.json
        post_id = data.get('post_id')
        reasons = data.get('reasons', [])
        other = data.get('other', '')
        original_idea = data.get('original_idea')
        
        # Regenerate with feedback
        post = content_agent.regenerate_with_feedback(
            original_idea,
            reasons,
            other
        )
        
        return jsonify({
            'success': True,
            'post': post
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/suggest_image/<post_id>')
def suggest_image(post_id):
    """Suggest image ideas for approved post"""
    try:
        ideas = content_agent.suggest_image_ideas(post_id)
        return jsonify({'success': True, 'ideas': ideas})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/generate_image', methods=['POST'])
def generate_image():
    """Generate image using Claude Imagine"""
    try:
        data = request.json
        post_id = data.get('post_id')
        image_idea = data.get('image_idea')
        
        # Generate image
        image_url = content_agent.generate_image_with_claude(
            post_id,
            image_idea
        )
        
        return jsonify({
            'success': True,
            'image_url': image_url
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/finalize_post/<post_id>', methods=['POST'])
def finalize_post(post_id):
    """Finalize post with optional image"""
    try:
        data = request.json
        image_url = data.get('image_url')
        
        memory.finalize_post(post_id, image_url)
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/generate_batch', methods=['POST'])
def generate_batch():
    """Generate 5 posts at once (batch mode after 10 posts)"""
    try:
        stats = memory.get_stats()
        
        if stats['total'] < 10:
            return jsonify({
                'success': False,
                'error': 'Batch-Modus erst ab 10 Posts verfügbar'
            }), 403
        
        posts = content_agent.generate_batch_posts(count=5)
        
        return jsonify({
            'success': True,
            'count': len(posts)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/transcribe', methods=['POST'])
def transcribe():
    """Transcribe audio to text"""
    try:
        if 'audio' not in request.files:
            return jsonify({'success': False, 'error': 'No audio file'}), 400
        
        audio_file = request.files['audio']
        
        # Save temporarily
        temp_path = memory.base_path / 'temp' / f'audio_{datetime.now().timestamp()}.webm'
        temp_path.parent.mkdir(exist_ok=True)
        audio_file.save(temp_path)
        
        # Transcribe using Claude (or Whisper API)
        # For now, using a placeholder
        # TODO: Implement actual transcription
        transcription = "Placeholder transcription - implement with Whisper API or Claude"
        
        # Clean up
        temp_path.unlink()
        
        return jsonify({
            'success': True,
            'text': transcription
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/onboarding')
def onboarding():
    """Onboarding Wizard"""
    profile = memory.load_profile()
    if profile:
        return redirect('/')
    
    return render_template('onboarding.html')


@app.route('/onboarding/save_step', methods=['POST'])
def save_onboarding_step():
    """Auto-save nach jedem Schritt"""
    try:
        data = request.json
        step = data.get('step')
        step_data = data.get('data')
        
        # Speichere in temporärem File
        import json
        temp_path = memory.base_path / 'memory' / 'onboarding_temp.json'
        
        if temp_path.exists():
            with open(temp_path, 'r') as f:
                saved_data = json.load(f)
        else:
            saved_data = {}
        
        saved_data.update(step_data)
        
        with open(temp_path, 'w') as f:
            json.dump(saved_data, f, indent=2)
        
        return jsonify({'success': True})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/onboarding/submit', methods=['POST'])
def submit_onboarding():
    """Process Onboarding"""
    try:
        profile_data = {
            'name': request.form.get('name'),
            'role': request.form.get('role'),
            'industry': request.form.get('industry'),
            'website': request.form.get('website', ''),
            'linkedin_url': request.form.get('linkedin_url', ''),
            'instagram': request.form.get('instagram', ''),
            'twitter': request.form.get('twitter', ''),
            'other_networks': request.form.get('other_networks', ''),
            'target_audience': request.form.get('target_audience'),
            'positioning': request.form.get('positioning'),
            'topic_1': request.form.get('topic_1'),
            'topic_2': request.form.get('topic_2'),
            'topic_3': request.form.get('topic_3')
        }
        
        memory.save_profile(profile_data)
        
        # Writing samples
        writing_samples = request.form.get('writing_samples', '')
        if writing_samples:
            samples = [s.strip() for s in writing_samples.split('\n\n') if s.strip()]
            
            if len(samples) >= 3:
                brand_voice = research_agent.analyze_brand_voice(samples)
                memory.save_brand_voice(brand_voice)
                memory.save_writing_samples(samples)
        
        return jsonify({'success': True, 'redirect': '/'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/generate', methods=['POST'])
def generate_proposals():
    """Generate new content proposals"""
    try:
        # 1. Research
        print("🔍 Research Agent...")
        research_data = research_agent.gather_insights()
        
        if not research_data:
            return jsonify({
                'success': False,
                'error': 'Research Agent konnte keine Daten sammeln. Bitte versuchen Sie es erneut.'
            }), 500
        
        # 2. Content Generation
        print("✍️ Content Agent...")
        proposals = content_agent.generate_proposals(research_data, count=5)
        
        if not proposals or len(proposals) == 0:
            return jsonify({
                'success': False,
                'error': 'Content Agent konnte keine Posts generieren. Bitte versuchen Sie es erneut.'
            }), 500
        
        print(f"✅ {len(proposals)} Vorschläge erstellt!")
        return jsonify({
            'success': True,
            'count': len(proposals),
            'message': f'{len(proposals)} neue Vorschläge erstellt!'
        })
        
    except Exception as e:
        import traceback
        print(f"❌ Error: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/approve/<proposal_id>', methods=['POST'])
def approve_proposal(proposal_id):
    """Approve proposal"""
    try:
        memory.update_proposal_status(proposal_id, 'approved')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/reject/<proposal_id>', methods=['POST'])
def reject_proposal(proposal_id):
    """Reject proposal"""
    try:
        reason = request.json.get('reason', '') if request.is_json else ''
        memory.update_proposal_status(proposal_id, 'rejected', reason)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/stats')
def get_stats():
    """Get statistics"""
    return jsonify(memory.get_stats())


@app.route('/api/best_times')
def get_best_times():
    """Get best posting times"""
    try:
        times = analytics_agent.analyze_best_posting_times()
        return jsonify({'success': True, 'times': times})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/publish_post/<post_id>', methods=['POST'])
def publish_post(post_id):
    """Publish post to LinkedIn via Make.com"""
    try:
        data = request.json
        
        options = {
            'timing': data.get('timing', 'now'),  # now | optimal | custom
            'schedule_time': data.get('schedule_time'),
            'cta_link': data.get('cta_link'),
            'comment_delay': int(data.get('comment_delay', 30)),
            'comment_text': data.get('comment_text')
        }
        
        result = publishing_agent.publish_post(post_id, options)
        
        return jsonify(result)
        
    except Exception as e:
        import traceback
        print(f"❌ Publishing Error: {str(e)}")
        print(traceback.format_exc())
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/publishing/callback', methods=['POST'])
def publishing_callback():
    """Callback from Make.com after publishing"""
    try:
        data = request.json
        
        post_id = data.get('post_id')
        linkedin_post_id = data.get('linkedin_post_id')
        linkedin_url = data.get('linkedin_url')
        
        result = publishing_agent.confirm_published(
            post_id,
            linkedin_post_id,
            linkedin_url
        )
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/publishing/status/<post_id>')
def get_publishing_status(post_id):
    """Get publishing status of a post"""
    try:
        status = publishing_agent.get_publishing_status(post_id)
        return jsonify({'success': True, 'status': status})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/cancel_scheduled/<post_id>', methods=['POST'])
def cancel_scheduled(post_id):
    """Cancel scheduled post"""
    try:
        result = publishing_agent.cancel_scheduled_post(post_id)
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


if __name__ == '__main__':
    print("\n" + "="*60)
    print("🤖 LinkedIn Agent - V4 Iterative + Publishing Edition")
    print("="*60)
    print("✅ Simple Memory System (No Google Drive needed)")
    print("✅ Iterative Post Generation")
    print("✅ Smart Publishing with Make.com")
    print("✅ Auto-Comment with CTA Links")
    print("="*60 + "\n")
    
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)

