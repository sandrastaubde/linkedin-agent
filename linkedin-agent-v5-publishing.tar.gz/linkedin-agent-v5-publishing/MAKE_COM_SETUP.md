# Make.com Setup Guide 🚀

**LinkedIn Agent Publishing in 5 Minuten**

---

## 📋 Voraussetzungen

- ✅ Make.com Account (kostenlos: make.com)
- ✅ LinkedIn Account
- ✅ Replit mit LinkedIn Agent V4

---

## 🚀 Setup (5 Minuten)

### **Schritt 1: Make.com Account**

```
1. Gehe zu make.com
2. "Sign up for free"
3. Email bestätigen
4. Einloggen
```

---

### **Schritt 2: Blueprint importieren**

```
1. Make.com Dashboard
2. Scenarios → "Create a new scenario"
3. ... Menü (3 Punkte) → "Import Blueprint"
4. Upload: MAKE_BLUEPRINT.json
5. "Save"
```

**✓ Scenario ist jetzt importiert!**

---

### **Schritt 3: LinkedIn verbinden**

```
Im Scenario:

1. Klicke auf Modul "LinkedIn: CreatePost" (ID 3)
2. "Add" → "Create a connection"
3. "Sign in with LinkedIn"
4. LinkedIn Account autorisieren
5. Connection wird gespeichert

✓ LinkedIn verbunden!
```

**WICHTIG:** Diese Connection wird automatisch in ALLEN LinkedIn-Modulen verwendet (CreatePost, CreateComment)

---

### **Schritt 4: Webhook URL kopieren**

```
1. Klicke auf erstes Modul "Webhook"
2. "Copy address to clipboard"
3. URL sieht aus wie:
   https://hook.eu1.make.com/abc123xyz...

✓ Webhook URL kopiert!
```

---

### **Schritt 5: In Replit einfügen**

```
Replit → Secrets (Schloss-Icon):

Key: MAKE_WEBHOOK_URL
Value: [paste your webhook URL]

→ Add Secret

✓ Agent kann jetzt mit Make.com kommunizieren!
```

---

### **Schritt 6: Callback URL (Optional)**

Damit Make.com zurück zu Ihrem Agent melden kann:

```
Replit Secrets:

Key: AGENT_CALLBACK_URL
Value: https://[your-replit-url]/publishing/callback

Dann in Make.com:
→ Modul "HTTP: Send Data" (ID 6 & 11)
→ URL: {{1.callback_url}}

✓ Two-way Communication!
```

---

### **Schritt 7: Scenario aktivieren**

```
Make.com Scenario:

1. Toggle Switch "ON" (oben rechts)
2. "Scheduling: Every 15 minutes" (oder "Immediately")

✓ Scenario ist aktiv!
```

---

## ✅ Test

### **Im LinkedIn Agent:**

```
1. Post erstellen
2. Genehmigen
3. "Veröffentlichen" klicken
4. Zeitpunkt: "Sofort"
5. CTA Link (optional): https://test.de
6. [Veröffentlichen]

→ Check Make.com: 
  "Runs" → sollte neuen Run zeigen
  
→ Check LinkedIn:
  Post sollte erscheinen!
  30 Sek später: Comment mit Link
```

---

## 🎯 Scenario Übersicht

**Was macht das Scenario?**

```
WEBHOOK empfängt Post-Daten
    ↓
ROUTER entscheidet:
├─ SOFORT Branch:
│  1. Post auf LinkedIn
│  2. Warte {{delay}} Sekunden
│  3. Comment mit Link
│  4. Callback zu Agent
│
└─ GEPLANT Branch:
   1. Warte bis {{schedule_time}}
   2. Post auf LinkedIn
   3. Warte {{delay}} Sekunden
   4. Comment mit Link
   5. Callback zu Agent
```

---

## 📊 Payload Structure

**Was sendet der Agent?**

```json
{
  "post_id": "abc123",
  "post_text": "Mein LinkedIn Post...",
  "image_url": "https://...",
  "hashtags": "#AI #Marketing",
  "schedule_time": null,  // null = sofort, oder ISO datetime
  "cta_link": "https://meine-website.de",
  "comment_delay": 30,  // Sekunden
  "comment_text": "Mehr Infos hier: {link}",  // optional
  "callback_url": "https://replit.../callback"
}
```

**Was kommt zurück?**

```json
{
  "success": true,
  "post_id": "abc123",
  "linkedin_post_id": "urn:li:share:123...",
  "linkedin_url": "https://linkedin.com/feed/update/...",
  "published_at": "2024-01-15T09:15:00"
}
```

---

## 🔧 Troubleshooting

### **Problem: "Webhook URL not configured"**
```
→ Check Replit Secrets
→ Key muss exakt sein: MAKE_WEBHOOK_URL
→ Keine Leerzeichen in der URL
```

### **Problem: "LinkedIn connection failed"**
```
→ Make.com → Scenario
→ LinkedIn Modul → Connection neu verbinden
→ LinkedIn Account autorisieren
```

### **Problem: "Post erscheint nicht auf LinkedIn"**
```
→ Make.com → Runs → Details ansehen
→ Check Fehler in LinkedIn-Modul
→ Evtl. LinkedIn Rate Limit (max 50 Posts/Tag)
```

### **Problem: "Comment erscheint nicht"**
```
→ Check: cta_link ist nicht leer
→ Check: comment_delay ist gesetzt (Min. 5 Sek)
→ Make.com Run Details → Comment-Modul Status
```

---

## 💰 Kosten Make.com

**Free Tier:**
- 1,000 Operations/Monat
- 1 Post mit Comment = ~6 Operations
- ✓ Reicht für: **~150 Posts/Monat**

**Core Tier ($10.59/Mo):**
- 10,000 Operations/Monat
- ✓ Reicht für: **~1,600 Posts/Monat**

---

## 🎨 Customization

### **Comment-Text ändern:**
```
Make.com → LinkedIn: CreateComment Modul

Text: {{if(1.comment_text; 1.comment_text; 'Mehr Infos: ' + 1.cta_link)}}

→ Ändere "Mehr Infos: " zu eigenem Text
```

### **Delay-Zeit ändern:**
```
Make.com → Sleep Modul

Delay: {{1.comment_delay}}

→ Oder feste Zeit: 45 (Sekunden)
```

### **Nur bestimmte Zeiten erlauben:**
```
Füge Filter hinzu nach Router:

Name: "Business Hours Only"
Condition: 
  {{hour(now)}} greater than 7
  AND
  {{hour(now)}} less than 20
```

---

## 🔐 Sicherheit

**Best Practices:**

1. ✅ Webhook URL geheim halten
2. ✅ Nie in GitHub committen
3. ✅ Nur in Replit Secrets
4. ✅ LinkedIn Connection regelmäßig erneuern

---

## 🚀 Ready!

**Setup komplett!** ✓

**Nächste Schritte:**

1. Teste mit einem Post
2. Check LinkedIn
3. Check Make.com Runs
4. Bei Erfolg: Produktiv nutzen!

---

## 📞 Support

**Bei Problemen:**

1. Make.com Docs: make.com/en/help
2. LinkedIn API: linkedin.com/developers
3. Replit Logs: Check Console Output

**Viel Erfolg!** 🎉
