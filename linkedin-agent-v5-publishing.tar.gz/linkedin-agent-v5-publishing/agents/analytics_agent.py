"""
Analytics Agent - Analysiert Posting-Zeiten und Engagement
"""

import json
from agents.base_agent import BaseAgent
from datetime import datetime, timedelta
from collections import defaultdict

class AnalyticsAgent(BaseAgent):
    def __init__(self, memory):
        role_card = {
            'name': 'Analytics Agent',
            'department': 'Data & Insights',
            'responsibility': 'Analyze posting times and engagement patterns',
            'voice_rules': 'Data-driven and precise',
            'governance': {
                'autonomous_decisions': ['Analyze patterns', 'Suggest optimal times'],
                'requires_approval': ['Change posting strategy'],
                'never_allowed': ['Publish content', 'Change user preferences']
            }
        }
        
        super().__init__(role_card, memory)
        self.skills = ['time_analysis', 'engagement_patterns', 'optimization']
    
    def analyze_best_posting_times(self):
        """Analysiert beste Posting-Zeiten basierend auf historischen Daten"""
        
        # Hole alle veröffentlichten Posts
        published_posts = self.memory.get_published_posts()
        
        if len(published_posts) < 5:
            # Nicht genug Daten - nutze Branchen-Defaults
            return self._get_default_times()
        
        # Gruppiere nach Wochentag + Stunde
        engagement_by_time = defaultdict(list)
        
        for post in published_posts:
            if not post.get('posted_at') or not post.get('engagement'):
                continue
            
            posted_at = datetime.fromisoformat(post['posted_at'])
            engagement = post['engagement']
            
            weekday = posted_at.strftime('%A')
            hour = posted_at.hour
            
            # Engagement-Score berechnen
            score = (
                engagement.get('likes', 0) * 1 +
                engagement.get('comments', 0) * 3 +
                engagement.get('shares', 0) * 5
            )
            
            key = f"{weekday}_{hour:02d}"
            engagement_by_time[key].append(score)
        
        # Durchschnitt berechnen
        avg_engagement = {}
        for time_key, scores in engagement_by_time.items():
            avg_engagement[time_key] = sum(scores) / len(scores)
        
        # Top 3 Zeiten
        top_times = sorted(
            avg_engagement.items(),
            key=lambda x: x[1],
            reverse=True
        )[:3]
        
        # Formatiere Ergebnisse
        results = []
        for time_key, score in top_times:
            weekday, hour = time_key.split('_')
            results.append({
                'weekday': weekday,
                'hour': int(hour),
                'time_display': f"{weekday}, {int(hour):02d}:00 Uhr",
                'engagement_score': round(score, 1),
                'confidence': 'high' if len(published_posts) > 20 else 'medium'
            })
        
        return {
            'recommended': results[0] if results else None,
            'alternatives': results[1:] if len(results) > 1 else [],
            'data_points': len(published_posts),
            'reasoning': f"Basierend auf {len(published_posts)} veröffentlichten Posts"
        }
    
    def _get_default_times(self):
        """Standard-Zeiten wenn nicht genug Daten vorhanden"""
        
        context = self.load_context()
        profile = context.get('profile', {})
        industry = profile.get('industry', 'general')
        
        # Branchen-spezifische Defaults
        defaults = {
            'Marketing & Kommunikation': [
                {'weekday': 'Tuesday', 'hour': 9, 'time_display': 'Dienstag, 09:00 Uhr'},
                {'weekday': 'Wednesday', 'hour': 10, 'time_display': 'Mittwoch, 10:00 Uhr'},
                {'weekday': 'Thursday', 'hour': 14, 'time_display': 'Donnerstag, 14:00 Uhr'}
            ],
            'Beratung & Coaching': [
                {'weekday': 'Tuesday', 'hour': 8, 'time_display': 'Dienstag, 08:00 Uhr'},
                {'weekday': 'Thursday', 'hour': 9, 'time_display': 'Donnerstag, 09:00 Uhr'},
                {'weekday': 'Wednesday', 'hour': 13, 'time_display': 'Mittwoch, 13:00 Uhr'}
            ],
            'Technologie & Innovation': [
                {'weekday': 'Tuesday', 'hour': 10, 'time_display': 'Dienstag, 10:00 Uhr'},
                {'weekday': 'Wednesday', 'hour': 11, 'time_display': 'Mittwoch, 11:00 Uhr'},
                {'weekday': 'Thursday', 'hour': 15, 'time_display': 'Donnerstag, 15:00 Uhr'}
            ]
        }
        
        times = defaults.get(industry, defaults['Marketing & Kommunikation'])
        
        return {
            'recommended': times[0],
            'alternatives': times[1:],
            'data_points': 0,
            'reasoning': 'Branchen-Standards (noch keine eigenen Daten)',
            'confidence': 'low'
        }
    
    def get_next_optimal_time(self):
        """Berechnet nächsten optimalen Posting-Zeitpunkt"""
        
        best_times = self.analyze_best_posting_times()
        recommended = best_times['recommended']
        
        if not recommended:
            return None
        
        # Finde nächstes Vorkommen dieser Zeit
        now = datetime.now()
        target_weekday = recommended['weekday']
        target_hour = recommended['hour']
        
        # Map weekday name to number (Monday = 0)
        weekday_map = {
            'Monday': 0, 'Tuesday': 1, 'Wednesday': 2, 
            'Thursday': 3, 'Friday': 4, 'Saturday': 5, 'Sunday': 6
        }
        
        target_weekday_num = weekday_map.get(target_weekday, 1)
        current_weekday = now.weekday()
        
        # Berechne Tage bis zum Ziel-Wochentag
        days_ahead = target_weekday_num - current_weekday
        if days_ahead <= 0:  # Target day already happened this week
            days_ahead += 7
        
        next_time = now + timedelta(days=days_ahead)
        next_time = next_time.replace(hour=target_hour, minute=0, second=0, microsecond=0)
        
        # Wenn heute ist der richtige Tag aber Uhrzeit schon vorbei
        if days_ahead == 0 and next_time < now:
            next_time += timedelta(days=7)
        
        return {
            'datetime': next_time.isoformat(),
            'display': next_time.strftime('%A, %d.%m.%Y um %H:%M Uhr'),
            'weekday': target_weekday,
            'hour': target_hour,
            'confidence': recommended.get('confidence', 'medium')
        }
    
    def track_post_performance(self, post_id, engagement_data):
        """Tracked Performance eines veröffentlichten Posts"""
        
        self.memory.update_post_engagement(post_id, engagement_data)
        
        # Lerne aus Performance
        self._learn_from_performance(post_id, engagement_data)
    
    def _learn_from_performance(self, post_id, engagement_data):
        """Lernt aus Post-Performance"""
        
        # Hole Post Details
        post = self.memory.get_proposal(post_id)
        if not post:
            return
        
        # Berechne Engagement-Rate
        impressions = engagement_data.get('impressions', 1)
        total_engagement = (
            engagement_data.get('likes', 0) +
            engagement_data.get('comments', 0) * 2 +
            engagement_data.get('shares', 0) * 3
        )
        
        engagement_rate = (total_engagement / impressions * 100) if impressions > 0 else 0
        
        # Lerne Präferenzen
        if engagement_rate > 5:  # Guter Post
            preferences = self.memory.load_preferences()
            
            # Lerne bevorzugte Formate
            post_format = post.get('format', 'unknown')
            if post_format not in preferences.get('preferred_formats', []):
                preferences.setdefault('preferred_formats', []).append(post_format)
            
            # Lerne bevorzugte Topics
            topic = post.get('topic', 'unknown')
            if topic not in preferences.get('preferred_topics', []):
                preferences.setdefault('preferred_topics', []).append(topic)
            
            # Erhöhe Confidence
            preferences['learning_confidence'] = min(
                preferences.get('learning_confidence', 0) + 1,
                100
            )
            
            self.memory.save_preferences(preferences)
