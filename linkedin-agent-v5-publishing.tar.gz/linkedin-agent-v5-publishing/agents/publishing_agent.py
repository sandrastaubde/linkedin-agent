"""
Publishing Agent - Veröffentlicht Posts auf LinkedIn via Make.com
"""

import json
import requests
import os
from agents.base_agent import BaseAgent
from datetime import datetime

class PublishingAgent(BaseAgent):
    def __init__(self, memory, analytics_agent=None):
        role_card = {
            'name': 'Publishing Agent',
            'department': 'Publishing',
            'responsibility': 'Publish posts to LinkedIn via Make.com',
            'voice_rules': 'Reliable and precise',
            'governance': {
                'autonomous_decisions': ['Send to Make.com', 'Track publishing status'],
                'requires_approval': ['All posts before publishing'],
                'never_allowed': ['Publish without user confirmation', 'Change post content']
            }
        }
        
        super().__init__(role_card, memory)
        self.skills = ['linkedin_publishing', 'scheduling', 'webhook_integration']
        self.analytics_agent = analytics_agent
        
        # Make.com Webhook URL
        self.webhook_url = os.getenv('MAKE_WEBHOOK_URL')
    
    def publish_post(self, post_id, options=None):
        """
        Veröffentlicht Post auf LinkedIn via Make.com
        
        options = {
            'timing': 'now' | 'optimal' | 'custom',
            'schedule_time': '2024-01-15T09:00:00' (für custom),
            'cta_link': 'https://...',
            'comment_delay': 30,  # Sekunden
            'comment_text': 'Custom comment text (optional)'
        }
        """
        
        if not self.webhook_url:
            return {
                'success': False,
                'error': 'Make.com Webhook URL nicht konfiguriert. Bitte in Secrets setzen.'
            }
        
        # Hole Post
        post = self.memory.get_proposal(post_id)
        if not post:
            return {'success': False, 'error': 'Post nicht gefunden'}
        
        if post.get('status') != 'finalized':
            return {'success': False, 'error': 'Post muss erst finalized werden'}
        
        # Default options
        if not options:
            options = {'timing': 'now'}
        
        # Bestimme Publish-Zeit
        schedule_time = None
        
        if options['timing'] == 'optimal':
            if self.analytics_agent:
                optimal = self.analytics_agent.get_next_optimal_time()
                schedule_time = optimal['datetime'] if optimal else None
        elif options['timing'] == 'custom':
            schedule_time = options.get('schedule_time')
        # else: timing == 'now' → schedule_time bleibt None
        
        # Baue Webhook Payload
        payload = {
            'post_id': post_id,
            'post_text': post.get('text', ''),
            'image_url': post.get('image_url'),
            'hashtags': ' '.join(post.get('hashtags', [])),
            'schedule_time': schedule_time,  # None = sofort
            'cta_link': options.get('cta_link'),
            'comment_delay': options.get('comment_delay', 30),
            'comment_text': options.get('comment_text'),
            'user_id': self._get_user_id()
        }
        
        # Sende zu Make.com
        try:
            response = requests.post(
                self.webhook_url,
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                # Update Post Status
                self.memory.update_post_status(post_id, 'publishing')
                
                if schedule_time:
                    self.memory.save_json('publishing', f'{post_id}_scheduled.json', {
                        'post_id': post_id,
                        'scheduled_for': schedule_time,
                        'created_at': str(datetime.now())
                    })
                else:
                    self.memory.save_json('publishing', f'{post_id}_published.json', {
                        'post_id': post_id,
                        'published_at': str(datetime.now())
                    })
                
                return {
                    'success': True,
                    'scheduled': schedule_time is not None,
                    'schedule_time': schedule_time,
                    'message': 'Post wird veröffentlicht...' if not schedule_time else f'Post geplant für {schedule_time}'
                }
            else:
                return {
                    'success': False,
                    'error': f'Make.com Fehler: {response.status_code}'
                }
                
        except requests.exceptions.Timeout:
            return {
                'success': False,
                'error': 'Timeout - Make.com nicht erreichbar'
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'Fehler beim Senden: {str(e)}'
            }
    
    def _get_user_id(self):
        """Holt LinkedIn User ID aus Profile"""
        context = self.load_context()
        profile = context.get('profile', {})
        
        # Extrahiere aus LinkedIn URL
        linkedin_url = profile.get('linkedin_url', '')
        if linkedin_url:
            # z.B. https://linkedin.com/in/sandra-schmidt
            parts = linkedin_url.rstrip('/').split('/')
            if len(parts) > 0:
                return parts[-1]
        
        # Fallback: Name
        return profile.get('name', 'user').lower().replace(' ', '_')
    
    def confirm_published(self, post_id, linkedin_post_id, linkedin_url):
        """
        Callback von Make.com nach erfolgreicher Veröffentlichung
        """
        
        self.memory.update_post_status(post_id, 'published')
        
        # Speichere LinkedIn Details
        self.memory.save_json('publishing', f'{post_id}_details.json', {
            'post_id': post_id,
            'linkedin_post_id': linkedin_post_id,
            'linkedin_url': linkedin_url,
            'published_at': str(datetime.now())
        })
        
        return {'success': True}
    
    def get_publishing_status(self, post_id):
        """Holt Publishing-Status eines Posts"""
        
        # Check scheduled
        scheduled = self.memory.load_json('publishing', f'{post_id}_scheduled.json')
        if scheduled:
            return {
                'status': 'scheduled',
                'scheduled_for': scheduled['scheduled_for']
            }
        
        # Check published
        published = self.memory.load_json('publishing', f'{post_id}_published.json')
        if published:
            details = self.memory.load_json('publishing', f'{post_id}_details.json')
            return {
                'status': 'published',
                'published_at': published['published_at'],
                'linkedin_url': details.get('linkedin_url') if details else None
            }
        
        return {'status': 'not_published'}
    
    def cancel_scheduled_post(self, post_id):
        """Bricht geplanten Post ab"""
        
        # TODO: Make.com API call um Schedule zu löschen
        # Für jetzt: Nur lokalen Status löschen
        
        scheduled_file = self.memory.base_path / 'publishing' / f'{post_id}_scheduled.json'
        if scheduled_file.exists():
            scheduled_file.unlink()
            
            self.memory.update_post_status(post_id, 'finalized')
            
            return {'success': True, 'message': 'Geplanter Post abgebrochen'}
        
        return {'success': False, 'error': 'Post ist nicht geplant'}
    
    def generate_comment_text(self, cta_link, custom_text=None):
        """Generiert Comment-Text für CTA Link"""
        
        if custom_text:
            # User hat eigenen Text - füge Link ein
            if '{link}' in custom_text:
                return custom_text.replace('{link}', cta_link)
            else:
                return f"{custom_text}\n\n{cta_link}"
        else:
            # Standard-Text
            return f"Mehr Infos: {cta_link}"
