"""
Content Agent - Generiert LinkedIn Posts
"""

import json
from agents.base_agent import BaseAgent
from datetime import datetime
import random
import uuid

class ContentAgent(BaseAgent):
    def __init__(self, memory):
        role_card = {
            'name': 'Content Agent',
            'department': 'Marketing',
            'responsibility': 'Generate LinkedIn posts in brand voice',
            'voice_rules': 'Match user brand voice exactly',
            'governance': {
                'autonomous_decisions': ['Generate post drafts'],
                'requires_approval': ['All posts before publishing'],
                'never_allowed': ['Publish without approval', 'Off-brand content']
            }
        }
        
        super().__init__(role_card, memory)
        self.skills = ['post_generation', 'linkedin_optimization']
        
        # Lade KI-Bild-Prompts
        self.image_prompts = self._load_image_prompts()
    
    def _load_image_prompts(self):
        """Lädt die 53 KI-Bild-Prompts für Frauen"""
        # TODO: Read from KI_BILD_PROMPTS_FRAUEN.md
        # For now, return sample prompts
        return {
            'business_executive': {
                'title': 'Executive Office',
                'description': 'Sie am Kopfende eines Konferenztisches, Hände elegant gefaltet, ruhiger Blick in die Kamera. Glaswand mit Skyline im Hintergrund. Natürliches Licht, Executive-Atmosphäre.',
                'prompt_template': '{name} sitzt am Kopfende eines langen Konferenztisches aus dunklem Holz, die Hände elegant gefaltet. Der Blick ist ruhig und bestimmt, direkt in die Kamera. Im Hintergrund eine Glaswand mit unscharfer Skyline. Natürliches Licht von der Seite. Sony Alpha, 85mm, f/2.0. Seriöse Executive-Atmosphäre. Bildformat 4:5.'
            },
            'thought_leader': {
                'title': 'Thought Leader',
                'description': 'Sie erklären mit offenen Händen, direkter Blickkontakt zur Kamera. Schlichter Hintergrund, Ring-Licht in den Augen. Content-Creator-Vibe.',
                'prompt_template': '{name} erklärt etwas mit offenen Händen, direkter Blickkontakt zur Kamera. Der Ausdruck ist überzeugend und einladend. Schlichter, unscharfer Hintergrund (Büro oder Studio). Ring-Licht-Reflexion in den Augen. Content-Creator-Vibe. 50mm, f/1.8. Bildformat 4:5.'
            },
            'casual_cafe': {
                'title': 'Coffee Shop Entrepreneur',
                'description': 'Sie im Café am Fenster, Laptop offen, Kaffee daneben. Warmes Café-Licht, entspannte Produktivität.',
                'prompt_template': '{name} sitzt in einem belebten Café am Fenster, Laptop offen, ein Flat White daneben. Der Blick ist auf den Bildschirm gerichtet, ein leichtes Lächeln. Durch die Scheibe sieht man das urbane Treiben. Warmes Café-Licht, entspannte Produktivität. 35mm. Bildformat 4:5.'
            },
            'speaker': {
                'title': 'Keynote Speaker',
                'description': 'Sie auf der Bühne, Hände in erklärender Geste. Scheinwerferlicht, Publikum im Hintergrund. TEDx-Atmosphäre.',
                'prompt_template': '{name} steht auf einer Bühne, Hände in erklärender Geste geöffnet. Scheinwerferlicht von oben erzeugt dramatische Schatten. Das Publikum ist als unscharfe Silhouetten im Vordergrund angedeutet. Selbstbewusste Körperhaltung, lebendiger Gesichtsausdruck. Cinematic, 35mm. Bildformat 4:5.'
            },
            'bold_rooftop': {
                'title': 'Bold Rooftop Vision',
                'description': 'Sie auf einem Dach mit Stadtpanorama. Wind im Haar, weiter Blick. Golden Hour, visionär.',
                'prompt_template': '{name} steht auf einem Dach mit Stadtpanorama im Hintergrund. Der Wind greift leicht ins Haar. Weiter Blick, visionäre Haltung. Golden Hour. Cinematic, 35mm. Bildformat 4:5.'
            }
        }
    
    def generate_single_post(self, idea):
        """Generiert einen einzelnen Post iterativ"""
        
        context = self.load_context()
        profile = context.get('profile', {})
        brand_voice = context.get('brand_voice', {})
        
        # Verarbeite Idee
        if isinstance(idea, dict):
            # Fragebogen
            idea_text = f"Thema: {idea.get('theme')}, Ton: {idea.get('tone')}, Zielgruppe: {idea.get('audience')}"
        else:
            # Text oder Transkription
            idea_text = str(idea)
        
        post = self._generate_from_idea(
            idea_text,
            profile,
            brand_voice
        )
        
        if post:
            post['id'] = str(uuid.uuid4())
            post['status'] = 'draft'
            post['idea_summary'] = idea_text[:100]
            
            # Speichere
            self.memory.save_proposal(post)
            
        return post
    
    def regenerate_with_feedback(self, original_idea, reasons, other):
        """Regeneriert Post mit Feedback"""
        
        context = self.load_context()
        profile = context.get('profile', {})
        brand_voice = context.get('brand_voice', {})
        
        # Baue Feedback-Prompt
        feedback = "Der vorherige Post wurde abgelehnt wegen:\n"
        
        reason_map = {
            'topic': 'Thema verfehlt',
            'length': 'Falsche Länge',
            'tone': 'Ton unpassend',
            'personality': 'Keine Persönlichkeit',
            'hashtags': 'Hashtags unpassend'
        }
        
        for r in reasons:
            feedback += f"- {reason_map.get(r, r)}\n"
        
        if other:
            feedback += f"- {other}\n"
        
        feedback += "\nBitte erstelle einen NEUEN Post der diese Kritikpunkte berücksichtigt."
        
        prompt = f"""Erstelle einen VERBESSERTEN LinkedIn Post.

URSPRÜNGLICHE IDEE: {original_idea}

FEEDBACK VOM USER:
{feedback}

PROFIL:
- Name: {profile.get('name', 'User')}
- Rolle: {profile.get('role', '')}
- Zielgruppe: {profile.get('target_audience', '')}

BRAND VOICE:
- Tonalität: {brand_voice.get('tone', 'professional')}
- Stil: {brand_voice.get('writing_style', 'clear')}

ANFORDERUNGEN:
- Länge: 150-200 Wörter (MAX 3000 Zeichen!)
- Berücksichtige das Feedback!
- LinkedIn-optimiert
- In der Brand Voice

OUTPUT als JSON:
{{
    "text": "Der Post",
    "hashtags": ["#Tag1", "#Tag2", "#Tag3"],
    "improvements": "Was wurde verbessert"
}}
"""
        
        response = self.call_claude(prompt, max_tokens=2000)
        
        try:
            if "```json" in response:
                response = response.split("```json")[1].split("```")[0].strip()
            
            post = json.loads(response)
            post['id'] = str(uuid.uuid4())
            post['status'] = 'draft'
            post['regenerated'] = True
            
            # Speichere
            self.memory.save_proposal(post)
            
            return post
            
        except Exception as e:
            print(f"❌ Regeneration Error: {str(e)}")
            return None
    
    def suggest_image_ideas(self, post_id):
        """Schlägt Top 5 Bild-Ideen für Post vor"""
        
        post = self.memory.get_proposal(post_id)
        if not post:
            return []
        
        context = self.load_context()
        profile = context.get('profile', {})
        
        # Analysiere Post um passende Bilder zu finden
        post_text = post.get('text', '')
        
        # Top 1: Basierend auf Post-Content
        top_idea = self._select_best_image_idea(post_text, profile)
        
        # 4 Alternativen
        alternatives = [
            self.image_prompts['business_executive'],
            self.image_prompts['casual_cafe'],
            self.image_prompts['speaker'],
            self.image_prompts['bold_rooftop']
        ]
        
        # Entferne Top Idea aus Alternativen
        alternatives = [a for a in alternatives if a['title'] != top_idea['title']][:4]
        
        ideas = [top_idea] + alternatives
        
        # Füge Reason hinzu
        for i, idea in enumerate(ideas):
            if i == 0:
                idea['reason'] = f"Passt perfekt zu Ihrem Post über {post.get('idea_summary', 'dieses Thema')[:50]}"
            else:
                idea['reason'] = "Alternative Option"
        
        return ideas
    
    def _select_best_image_idea(self, post_text, profile):
        """Wählt beste Bild-Idee basierend auf Post-Inhalt"""
        
        # Einfache Keyword-Analyse
        text_lower = post_text.lower()
        
        if any(word in text_lower for word in ['strategi', 'business', 'führung', 'executive']):
            return self.image_prompts['business_executive']
        elif any(word in text_lower for word in ['lernen', 'erklär', 'tipp', 'trick']):
            return self.image_prompts['thought_leader']
        elif any(word in text_lower for word in ['vortrag', 'bühne', 'speaker', 'talk']):
            return self.image_prompts['speaker']
        elif any(word in text_lower for word in ['entspann', 'café', 'kaffee', 'remote']):
            return self.image_prompts['casual_cafe']
        else:
            # Default
            return self.image_prompts['thought_leader']
    
    def generate_image_with_claude(self, post_id, image_idea):
        """Generiert Bild mit Claude Imagine"""
        
        context = self.load_context()
        profile = context.get('profile', {})
        photos = context.get('photos', [])
        
        # Extrahiere Person-Description aus Fotos
        # TODO: Implement photo analysis
        person_desc = f"{profile.get('name', 'Professionelle Frau')}, ca. 35-40 Jahre"
        
        # Baue Prompt
        prompt = image_idea['prompt_template'].replace('{name}', person_desc)
        
        # Call Claude Imagine
        # TODO: Implement actual Claude Imagine call
        # For now return placeholder
        image_url = f"https://placeholder.com/image_{post_id}.jpg"
        
        # Speichere
        self.memory.update_post_image(post_id, image_url)
        
        return image_url
    
    def generate_batch_posts(self, count=5):
        """Generiert mehrere Posts auf einmal (Batch-Modus)"""
        
        context = self.load_context()
        profile = context.get('profile', {})
        
        # Hole Research Data
        research_data = self.connected_agents.get('research_agent').gather_insights()
        
        return self.generate_proposals(research_data, count)
    
    def _generate_from_idea(self, idea, profile, brand_voice):
        """Generiert Post aus Idee"""
        
        prompt = f"""Erstelle einen LinkedIn Post basierend auf dieser Idee.

IDEE: {idea}

PROFIL:
- Name: {profile.get('name', 'User')}
- Rolle: {profile.get('role', '')}
- Zielgruppe: {profile.get('target_audience', '')}
- Positionierung: {profile.get('positioning', '')}

BRAND VOICE:
- Tonalität: {brand_voice.get('tone', 'professional')}
- Stil: {brand_voice.get('writing_style', 'clear')}
- Unique Voice: {brand_voice.get('unique_voice', '')}

ANFORDERUNGEN:
- Länge: 150-200 Wörter (MAX 3000 Zeichen!)
- Hook in ersten 1-2 Zeilen
- Konkreter Mehrwert
- LinkedIn-optimiert
- In der Brand Voice

OUTPUT als JSON:
{{
    "text": "Der komplette Post",
    "hashtags": ["#Tag1", "#Tag2", "#Tag3"]
}}
"""
        
        response = self.call_claude(prompt, max_tokens=2000)
        
        if not response:
            return None
        
        try:
            if "```json" in response:
                response = response.split("```json")[1].split("```")[0].strip()
            
            post = json.loads(response)
            post['generated_at'] = str(datetime.now())
            
            return post
            
        except Exception as e:
            print(f"❌ Content Gen Error: {str(e)}")
            return None
    
    def generate_proposals(self, research_data, count=5):
        """Generiert mehrere Post-Vorschläge (für Batch)"""
        
        context = self.load_context()
        profile = context.get('profile', {})
        brand_voice = context.get('brand_voice', {})
        
        topics = [
            profile.get('topic_1', ''),
            profile.get('topic_2', ''),
            profile.get('topic_3', '')
        ]
        
        # Nutze Research Insights
        angles = research_data.get('content_angles', [])[:count]
        hooks = research_data.get('hooks', [])
        
        proposals = []
        
        for i, angle in enumerate(angles):
            hook = hooks[i] if i < len(hooks) else {"hook": "Interesting insight..."}
            
            proposal = self._generate_single_post_old(
                angle=angle,
                hook=hook,
                topics=topics,
                profile=profile,
                brand_voice=brand_voice
            )
            
            if proposal:
                proposal['id'] = f"post_{datetime.now().strftime('%Y%m%d%H%M%S')}_{i}"
                proposal['status'] = 'pending'
                
                # Speichere in Memory
                self.memory.save_proposal(proposal)
                proposals.append(proposal)
        
        return proposals
    
    def _generate_single_post_old(self, angle, hook, topics, profile, brand_voice):
        """Generiert einen einzelnen Post (alte Methode für Batch)"""
        
        prompt = f"""Erstelle einen LinkedIn Post.

PROFIL:
- Name: {profile.get('name', 'User')}
- Rolle: {profile.get('role', '')}
- Zielgruppe: {profile.get('target_audience', '')}
- Positionierung: {profile.get('positioning', '')}

HAUPTTHEMEN: {', '.join(topics)}

BRAND VOICE:
- Tonalität: {brand_voice.get('tone', 'professional')}
- Stil: {brand_voice.get('writing_style', 'clear')}
- Unique Voice: {brand_voice.get('unique_voice', '')}

CONTENT ANGLE: {angle.get('angle', '')}
FORMAT: {angle.get('format', 'opinion')}
HOOK: {hook.get('hook', '')}

ANFORDERUNGEN:
- Länge: 150-200 Wörter (MAX 3000 Zeichen - LinkedIn Limit!)
- Hook in ersten 1-2 Zeilen
- Konkreter Mehrwert
- LinkedIn-optimiert (Absätze, klar strukturiert)
- Passt zu einem der 3 Hauptthemen
- In der Brand Voice

OUTPUT als JSON:
{{
    "post_text": "Der Post (MAX 3000 Zeichen!)",
    "hook_line": "Erste Zeile",
    "hashtags": ["#Tag1", "#Tag2", "#Tag3"],
    "topic": "tema_1/2/3",
    "format": "{angle.get('format', 'opinion')}",
    "posting_time": "09:00",
    "estimated_engagement_score": 7,
    "reasoning": "Warum dieser Post funktioniert",
    "character_count": 0
}}
"""
        
        response = self.call_claude(prompt, max_tokens=2500)
        
        if not response:
            return None
        
        try:
            if "```json" in response:
                response = response.split("```json")[1].split("```")[0].strip()
            
            post = json.loads(response)
            
            # Validiere LinkedIn Limit
            char_count = len(post.get('post_text', ''))
            if char_count > 3000:
                post['post_text'] = post['post_text'][:2950] + '...'
                post['character_count'] = 2953
            else:
                post['character_count'] = char_count
            
            post['generated_at'] = str(datetime.now())
            
            return post
            
        except Exception as e:
            print(f"❌ Content Gen Error: {str(e)}")
            return None
