// Voice Recording Handler

let mediaRecorder = null;
let audioChunks = [];
let recordingStartTime = null;
let recordingInterval = null;
let transcribedText = null;

async function toggleRecording() {
    if (!mediaRecorder || mediaRecorder.state === 'inactive') {
        await startRecording();
    } else {
        stopRecording();
    }
}

async function startRecording() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];
        
        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };
        
        mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            await transcribeAudio(audioBlob);
        };
        
        mediaRecorder.start();
        recordingStartTime = Date.now();
        
        // UI Updates
        document.getElementById('voiceRecorder').classList.add('recording');
        document.getElementById('recordingIcon').textContent = '🔴';
        document.getElementById('recordingText').textContent = 'Aufnahme läuft...';
        document.getElementById('recordingTime').classList.remove('hidden');
        
        // Timer
        recordingInterval = setInterval(updateRecordingTime, 100);
        
        // Auto-stop after 60 seconds
        setTimeout(() => {
            if (mediaRecorder && mediaRecorder.state === 'recording') {
                stopRecording();
            }
        }, 60000);
        
    } catch (err) {
        console.error('Microphone access denied:', err);
        alert('Mikrofon-Zugriff wurde verweigert. Bitte erlauben Sie den Zugriff in Ihren Browser-Einstellungen.');
    }
}

function stopRecording() {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
        clearInterval(recordingInterval);
        
        // Stop all tracks
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
        
        // UI Updates
        document.getElementById('voiceRecorder').classList.remove('recording');
        document.getElementById('recordingIcon').textContent = '⏳';
        document.getElementById('recordingText').textContent = 'Wird transkribiert...';
    }
}

function updateRecordingTime() {
    const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;
    document.getElementById('recordingTime').textContent = 
        `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

async function transcribeAudio(audioBlob) {
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');
    
    try {
        const res = await fetch('/transcribe', {
            method: 'POST',
            body: formData
        });
        
        const data = await res.json();
        
        if (data.success) {
            transcribedText = data.text;
            
            // Show transcription
            document.getElementById('transcriptionText').textContent = data.text;
            document.getElementById('transcriptionContainer').classList.remove('hidden');
            
            // Reset recorder UI
            document.getElementById('recordingIcon').textContent = '🎤';
            document.getElementById('recordingText').textContent = 'Klicken zum Aufnehmen';
            document.getElementById('recordingTime').classList.add('hidden');
        } else {
            alert('Fehler bei der Transkription: ' + data.error);
            resetVoiceRecorder();
        }
    } catch (err) {
        console.error('Transcription error:', err);
        alert('Fehler bei der Transkription. Bitte versuchen Sie es erneut.');
        resetVoiceRecorder();
    }
}

function confirmTranscription() {
    if (transcribedText) {
        currentIdea = transcribedText;
        generatePost();
    }
}

function resetVoiceRecorder() {
    document.getElementById('recordingIcon').textContent = '🎤';
    document.getElementById('recordingText').textContent = 'Klicken zum Aufnehmen';
    document.getElementById('recordingTime').classList.add('hidden');
    document.getElementById('voiceRecorder').classList.remove('recording');
}
