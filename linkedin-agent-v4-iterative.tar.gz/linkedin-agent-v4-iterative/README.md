# LinkedIn Agent V4 - Iterative Edition 🚀

**Der intelligente LinkedIn-Content-Generator mit iterativem Workflow**

## 🎯 NEUE FEATURES V4

✅ **Iterativer Post-Workflow** - 1 nach dem anderen (Batch ab Post 10)
✅ **Sprachnachricht** - Post-Idee als Audio aufnehmen  
✅ **Smart Post-Ideation** - Text / Sprache / News / Fragebogen
✅ **Rejection-Gründe** - Agent lernt aus Feedback
✅ **Lazy Image Loading** - Top 1 Idee first, Alternativen on-demand
✅ **5 Fotos PFLICHT** - Für personalisierte KI-Bilder
✅ **16-Schritt Wizard** - Mit Zurück-Button & Auto-Resume

## 📦 SETUP (5 Min)

1. Upload zu Replit
2. `pip install anthropic flask --break-system-packages`
3. API Key in Secrets: `ANTHROPIC_API_KEY`
4. `python main.py`
5. Onboarding durchlaufen

## 🚀 WORKFLOW

1. Post-Idee (Text/Sprache/News/Fragebogen)
2. Post wird generiert
3. Review: Genehmigen/Bearbeiten/Ablehnen
4. Bei Ablehnung: Feedback → Neu generieren
5. Bei Genehmigung: Bild? Ja/Nein
6. Top Bild-Idee → Generieren/Alternativen
7. Post komplett → Nächster Post?

## 💰 KOSTEN

Iterativ: ~$1-1.50/Session (50% Ersparnis vs Batch)  
Approval Rate: 75% (vs 40% Batch)

## 📸 KI-BILDER

53 Prompts in 5 Kategorien:
- Business (Executive, Speaker, Strategist)
- Business Casual (Deep Work, Meetings)
- Casual (Café, Behind Scenes)
- Random (Rooftop, Storytelling)
- Bold & Edgy (Humor, Provokant)

Details: `KI_BILD_PROMPTS_FRAUEN.md`

## 🔧 FILES

- `main.py` - Backend mit neuen Routes
- `agents/content_agent.py` - Iterativ + Bilder
- `agents/research_agent.py` - News-Fetching
- `templates/dashboard_v2.html` - Neuer Flow
- `templates/onboarding.html` - 16 Schritte
- `static/voice_handler.js` - Sprachaufnahme
- `memory/simple_memory.py` - Erweitert

Viel Erfolg! 🎉
