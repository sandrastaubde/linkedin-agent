# 🏛️ Design System - LinkedIn Agent (München Edition)

**Ästhetik:** Brenner's / Rosewood / Hugo's / Manufactum

**Philosophie:** Gedeckter europäischer Luxus, zeitlos statt trendy, "Old Money" Eleganz

---

## 🎨 Farbpalette

### Primärfarben
```css
/* Background */
--bg-gradient-start: #e8dcc8;  /* Warmes Beige */
--bg-gradient-end: #d4c4ab;    /* Taupe */

/* Cards & Surfaces */
--surface-primary: #faf8f5;    /* Creme/Marmor - Rosewood */
--surface-elevated: #ffffff;   /* Pure White für Highlights */

/* Buttons & Actions */
--primary: #2d4a3e;            /* Dunkelgrün - Brenner's */
--primary-dark: #1e3329;       /* Dunkleres Grün */
--primary-hover: #3a5f4f;      /* Hover State */

/* Akzente */
--accent-gold: #c9a961;        /* Gold/Messing */
--accent-copper: #b5956f;      /* Kupfer */
```

### Textfarben
```css
--text-primary: #2c2c2c;       /* Anthrazit - Haupttext */
--text-secondary: #6b5d52;     /* Warmes Braun - Subtitles */
--text-tertiary: #a89885;      /* Taupe - Placeholders */
--text-muted: #c4b5a5;         /* Sehr dezent */
```

### Borders & Dividers
```css
--border-light: #d4c4ab;       /* Standard Border */
--border-medium: #8b7355;      /* Active/Hover Border */
--border-dark: #5c4b3c;        /* Starke Trennung */
```

---

## 📐 Typografie

### Schriftarten
```css
/* Serif - für Headlines */
font-family: 'Cormorant Garamond', serif;
/* Sans-Serif - für Body */
font-family: 'Montserrat', sans-serif;
```

### Font Weights
```css
--weight-light: 300;
--weight-regular: 400;
--weight-medium: 500;
--weight-semibold: 600;
```

### Font Sizes
```css
/* Headlines */
--h1: 2.2em;                   /* 35px bei 16px base */
--h2: 1.8em;                   /* 29px */
--h3: 1.4em;                   /* 22px */

/* Body */
--body-large: 1.05em;          /* 17px */
--body: 1em;                   /* 16px */
--body-small: 0.95em;          /* 15px */
--caption: 0.85em;             /* 14px */
```

### Letter Spacing
```css
--spacing-tight: -0.02em;      /* Headlines */
--spacing-normal: 0;
--spacing-relaxed: 0.02em;     /* Body */
--spacing-wide: 0.08em;        /* Buttons (UPPERCASE) */
--spacing-wider: 0.1em;        /* Step Indicators */
```

---

## 🔲 Spacing & Layout

### Spacing Scale
```css
--space-xs: 6px;
--space-sm: 12px;
--space-md: 20px;
--space-lg: 30px;
--space-xl: 40px;
--space-2xl: 50px;
--space-3xl: 60px;
```

### Border Radius
```css
--radius-none: 0px;            /* Keine Rundung */
--radius-sm: 2px;              /* Minimal - Buttons, Cards */
--radius-md: 4px;              /* Selten verwendet */
--radius-circle: 50%;          /* Loading Spinner */
```

### Shadows
```css
--shadow-subtle: 0 8px 30px rgba(44, 44, 44, 0.08);
--shadow-medium: 0 4px 15px rgba(45, 74, 62, 0.25);
--shadow-inset: inset 0 0 0 1px #8b7355;
```

---

## 🎭 Components

### Button (Primary - Dunkelgrün)
```css
background: linear-gradient(135deg, #2d4a3e 0%, #1e3329 100%);
color: #faf8f5;
padding: 18px 40px;
border-radius: 2px;
font-size: 0.95em;
font-weight: 400;
letter-spacing: 0.08em;
text-transform: uppercase;
transition: all 0.3s ease;

/* Hover mit Shimmer */
&::before {
  content: '';
  position: absolute;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
  animation: shimmer 0.5s;
}

&:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 15px rgba(45, 74, 62, 0.25);
}
```

### Card
```css
background: #faf8f5;
border-radius: 2px;
padding: 60px 50px;
box-shadow: 0 8px 30px rgba(44, 44, 44, 0.08);
border: 1px solid rgba(139, 115, 85, 0.1);
```

### Input Field
```css
padding: 18px 0;
font-size: 1.05em;
border: none;
border-bottom: 1px solid #d4c4ab;
background: transparent;
color: #2c2c2c;
font-weight: 300;

&:focus {
  border-bottom-color: #8b7355;
}

&::placeholder {
  color: #a89885;
  font-weight: 300;
}
```

### Textarea
```css
min-height: 140px;
padding: 18px;
border: 1px solid #d4c4ab;
border-radius: 2px;
background: transparent;

&:focus {
  border-color: #8b7355;
}
```

### Option Card (Multiple Choice)
```css
padding: 24px 28px;
border: 1px solid #d4c4ab;
border-radius: 2px;
background: transparent;
transition: all 0.3s ease;

&:hover {
  border-color: #8b7355;
  background: rgba(139, 115, 85, 0.03);
}

&.selected {
  border-color: #8b7355;
  background: rgba(139, 115, 85, 0.06);
  box-shadow: inset 0 0 0 1px #8b7355;
}
```

### Progress Bar
```css
background: rgba(92, 75, 60, 0.15);
height: 2px;
border-radius: 2px;

.progress-fill {
  background: linear-gradient(90deg, #8b7355 0%, #c9a961 100%);
  transition: width 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
}
```

### Gold Divider
```css
width: 60px;
height: 1px;
background: linear-gradient(90deg, transparent, #c9a961, transparent);
margin: 30px auto;
```

---

## 🎬 Animationen

### Easing Functions
```css
--ease-standard: cubic-bezier(0.4, 0.0, 0.2, 1);
--ease-decelerate: cubic-bezier(0.0, 0.0, 0.2, 1);
--ease-accelerate: cubic-bezier(0.4, 0.0, 1, 1);
```

### Durations
```css
--duration-fast: 0.2s;
--duration-normal: 0.3s;
--duration-slow: 0.4s;
--duration-slower: 0.5s;
```

### Keyframes
```css
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(15px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

@keyframes shimmer {
  from { left: -100%; }
  to { left: 100%; }
}
```

---

## ✍️ Tone of Voice (UI Texte)

### Formell & Europäisch
- ✅ "Wie dürfen wir Sie nennen?"
- ❌ "Wie heißt du?"

- ✅ "Ihre Profession"
- ❌ "Was machst du beruflich?"

- ✅ "Einen Moment..."
- ❌ "Lädt gerade..."

- ✅ "Agent aktivieren"
- ❌ "Los geht's! 🚀"

### Buttons
- ✅ "Weiter" (nicht "Weiter →")
- ✅ "Agent aktivieren" (nicht "Agent starten!")
- ✅ Uppercase mit Letter-Spacing

### Alerts
- ✅ "Bitte geben Sie Ihren Namen ein."
- ❌ "Bitte Namen eingeben 😊"

---

## 📱 Responsive Breakpoints

```css
/* Mobile First */
@media (max-width: 600px) {
  .card { padding: 40px 30px; }
  .question { font-size: 1.8em; }
  .btn { padding: 16px 30px; }
}

@media (max-width: 400px) {
  .card { padding: 30px 20px; }
  .question { font-size: 1.6em; }
}
```

---

## 🏷️ Brand-Referenzen

### Brenner's München
- Dunkelgrün (#2d4a3e, #1e3329)
- Gold/Messing Akzente
- Warme Naturmaterialien-Optik
- Handwerkliche Qualität

### Rosewood München
- Taupe/Creme Marmor (#faf8f5, #e8dcc8)
- Warme Neutrals
- Generous Spacing (60px Padding!)
- Zeitlose Eleganz

### Hugo's
- Anthrazit/Grau Töne
- Dezente Luxus-Signale
- Reduziert, nicht überladen
- "Old Money" Feel

### Manufactum
- Natürliche Materialien-Look
- Beige, Off-White Palette
- Handwerklich, solide
- Kein Tech-Startup Vibe

---

## 🚫 Anti-Patterns (Was zu vermeiden ist)

### Farben
- ❌ Knallige Farben (Lila, Pink, Neon)
- ❌ Tech-Startup Gradients (Blau/Pink)
- ❌ Zu viel Schwarz/Weiß Kontrast

### Formen
- ❌ Große Border Radius (>4px)
- ❌ Runde Buttons
- ❌ Pill-Shapes

### Typografie
- ❌ Sans-Serif für Headlines
- ❌ Zu eng/weit Letter-Spacing
- ❌ Emojis im UI (nur in Content!)
- ❌ Casual Sprache ("Hey!", "Cool!")

### Animationen
- ❌ Bounce/Spring Animationen
- ❌ Zu schnell (<0.2s)
- ❌ Übertriebene Effekte

---

## 📐 Grid & Layout

```css
/* Container */
max-width: 650px;
padding: 20px;

/* Card Inner Padding */
Desktop: 60px 50px
Mobile: 40px 30px

/* Vertical Rhythm */
Question → 12px → Subtitle
Subtitle → 40px → Input
Input → 40px → Button
```

---

## 🎨 Verwendung

**Für neue Components:**
1. Starte mit Creme Card (#faf8f5)
2. Dunkelgrün für Primary Actions
3. Gold nur für Akzente/Dividers
4. Cormorant für Headlines
5. Montserrat für Body
6. Minimal Border Radius (2px)
7. Generous Spacing (40-60px)
8. Subtile Shadows

**Farbhierarchie:**
1. Creme/Beige (Dominant - 60%)
2. Dunkelgrün (Akzent - 30%)
3. Gold (Highlight - 10%)

---

**Dieses Design System gilt für ALLE Interfaces im LinkedIn Agent Projekt.**

Stand: 24. April 2026
